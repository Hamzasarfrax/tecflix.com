

<section class="sider_dashbord_login">
      <div class="side_nav" id="sidebar">
        <div class="icon_sidebar" onclick="sidebarToggle()">
          <i class="fa-solid fa-bars"></i>
        </div>
        <ul class="sidebar p-0">
          <li class="nav-items active">
            <div class="more_menu">
              <a href="Dashbord" class="menu_item">
                <div class="menu_icon">
                  <img src="../images/dashboard.svg" alt="" class="img" />
                </div>
                <div class="menu_name">Dashboard</div>
              </a>
            </div>
          </li>
          <li class="nav-items">
            <div class="more_menu">
              <a href="#" class="menu_item">
                <div class="menu_icon">
                  <img src="../images/products (2).svg" alt="" class="img" />
                </div>
                <div class="menu_name">products</div>
              </a>
            </div>
          </li>

          <li class="nav-items">
            <div class="more_menu">
              <a href="Order" class="menu_item">
                <div class="menu_icon">
                  <img src="../images/order.svg" alt="" class="img" />
                </div>
                <div class="menu_name">orders</div>
              </a>
            </div>
          </li>

          <li class="nav-items">
            <div class="more_menu">
              <a href="Report" class="menu_item">
                <div class="menu_icon">
                  <img src="../images/reports.svg " class="img" />
                </div>
                <div class="menu_name">reports</div>
              </a>
            </div>
          </li>
          <hr />
          <li class="nav-items">
            <div class="more_menu">
              <a href="Profile" class="menu_item">
                <div class="menu_icon">
                  <img src="../images/users.svg" class="img" />
                </div>
                <div class="menu_name">profile</div>
              </a>
            </div>
          </li>
          <li class="nav-items">
            <div class="more_menu">
              <a href="Setting" class="menu_item">
                <div class="menu_icon">
                  <img src="../images/settings.svg" class="img" />
                </div>
                <div class="menu_name">settings</div>
              </a>
            </div>
          </li>
        </ul>
      </div>
    </section>