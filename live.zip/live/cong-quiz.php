<!DOCTYPE html>
<html lang="en">
  <head>
     <title>Quiz Test</title>
  <?php
require_once("user_content/header.php")
?>
  <?php
require_once("user_content/css.php")
?>

<style>

</style>
  </head>
  <body>

  <main>


  <section class="section_congrats" id="section_congrats">
     <div class="container">
          <div class="row">
               <div class="box_contract">
                    <div class="imgs">
                         <img src="../images/clapping.svg" alt="" class="img_congs">
                    </div>
                    <div class="text_congs">
                         congratulations !
                    </div>
                    <div class="points">
                         your points
                         <br>
                         <span>
                              10
                         </span>
                    </div>
                    <div class="btns">
                         <a href="After_quiz_login.php" class="btn btn-main btn-congs">
                              show result
                         </a>
                    </div>
               </div>
          </div>
     </div>

</section>


    
</main>


  </body>

<?php
require_once("user_content/js.php")
?>
 

 
</html>
