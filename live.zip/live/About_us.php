<!DOCTYPE html>
<html lang="en">
  <head>
     <title>About_Us</title>
  <?php
require_once("user_content/header.php")
?>
  <?php
require_once("user_content/css.php")
?>

<style>

</style>
  </head>
  <body>
  <?php
require_once("user_content/top_menu.php")
?>
  <main>
  <section class="about_us">

    <div class="container">
         <div class="row">
              <div class="col-sm-6">
                   <div class="about_us_text">
                        want to know about us ?
                   </div>
              </div>
         </div>
    </div>

    

              
 <!-- thsis is bg img -->
 <div class="about_bg_img">
    <img src="assets/images/Background-About-us.svg" alt="">


    <div class=" container text_inside_bg_img">
         <div class="text_heading">
              about us
         </div>
         <div class="text_paragraph">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum maxime soluta, consequatur aperiam minus, accusantium quam modi aspernatur totam dolorum sapiente ipsam itaque cupiditate consectetur? Quidem quo quis ducimus consequatur!lorem
         </div>
         <div class="text_paragraph">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum maxime soluta, consequatur aperiam minus, accusantium quam modi aspernatur totam dolorum sapiente ipsam itaque cupiditate consectetur? Quidem quo quis ducimus consequatur!lorem
         </div>
              </div>
    </div>
  
</section>
</main>

<?php
require_once("sign_up.php")
?>	
        <?php
require_once("user_content/footer.php")
?>
  </body>

<?php
require_once("user_content/js.php")
?>
 

 
</html>
