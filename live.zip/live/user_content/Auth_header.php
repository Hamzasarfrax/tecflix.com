<header class="auth">
  <nav class="navbar navbar-expand-lg navbar-fixed ">
    <div class="brand-logo">
      <a class="navbar-brand" href="#">logo</a>
 </div>
 <div class="icon_sidebar" onclick="sidebarToggle()">
          <i class="fa-solid fa-bars"></i>
        </div>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon">
      <i class="fa fa-bars"></i>
      </span>
    </button>
  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
                
               
        <li class="nav-item d_flex_headr">
         <a class="nav-link" href="#">
           <div class="wallet_box_header">
                <div class="img">
              
                 <i class="fa fa-bell" aria-hidden="true">
                  
                 </i>
                </div>
           </div>
         </a>
       </li>
       <li class="nav-item d_flex_headr">
         <a class="nav-link" href="#">
           <div class="wallet_box_header">
                <div class="img">
                 <i class="fa fa-envelope" aria-hidden="true"></i>
                </div>
           </div>
         </a>
       </li>
       <li class="nav-item d_flex_headr">
         <a class="nav-link" href="index.php">
         <div class="wallet_box_header">
           <div class="img">
                <img src="https://dummyimage.com/50x50/000/fff" alt="" class="rounded-circle">
           </div>
         </div>
         </a>
       </li>
      </ul>
    
    </div>
  </nav>
</header>
