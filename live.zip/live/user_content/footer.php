




 <footer class="footer">
            <div class="footer-logo">
              <figure>
                <img src="https://dummyimage.com/200x100/000/fff&text=logo" alt=""  class=" rounded-circle"/>
              </figure>
               </div>
          <div class="container-fluid">
            <div class="row">
            
              <div class="col-sm-2">
              
                <nav class="footer-nav">
                 <li class="nav-item">
                      <a href="#" class="nav-link footer-heading">
                           contact:
                      </a>
                    </li>
                  <li class="nav-item">
                    <a href="tel:0320-12345678" class="nav-link">0320-12345678</a>
                  </li>
                </nav>
               
                <nav class="footer-nav">
  
                 <li class="nav-item">
                      <a href="#" class="nav-link footer-heading">
                           address:
                      </a>
                    </li>
                  <li class="nav-item">
                      
                    <a href="#" class="nav-link">Lorem ipsum dolor sit dollor.</a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link">Lorem ipsum dolor </a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link text-uppercase">ox4 56g.</a>
                  </li>
                </nav>
              </div>
              <div class="col-sm-2">
              
                <nav class="footer-nav">
  
                 <li class="nav-item">
                      <a href="#" class="nav-link footer-heading">
                           services
                      </a>
                    </li>
                  <li class="nav-item">
                    <a href="" class="nav-link">graphic designing</a>
                  </li>
                  <li class="nav-item">
                    <a href="" class="nav-link">website designing</a>
                  </li>
                  <li class="nav-item">
                    <a href="" class="nav-link">web development</a>
                  </li>
                  <li class="nav-item">
                    <a href="" class="nav-link">web development</a>
                  </li>
                  <li class="nav-item">
                    <a href="" class="nav-link">web development</a>
                  </li>
                  <li class="nav-item">
                    <a href="" class="nav-link">web development</a>
                  </li>
                </nav>
              </div>
              <div class="col-sm-2">
              
                <nav class="footer-nav">
                 <li class="nav-item">
                      <a href="#" class="nav-link footer-heading">
                           about us
                      </a>
                    </li>
                  <li class="nav-item">
                    <a href="" class="nav-link">careers</a>
                  </li>
                  <li class="nav-item">
                    <a href="" class="nav-link">terms &services</a>
                  </li>
                  <li class="nav-item">
                    <a href="" class="nav-link">privacy policy</a>
                  </li>
                  <li class="nav-item">
                    <a href="" class="nav-link">careers</a>
                  </li>
                </nav>
              </div>
              <div class="col-sm-2">
               
                <nav class="footer-nav">
                 <li class="nav-item">
                      <a href="#" class="nav-link footer-heading">
                           support
                      </a>
                    </li>
                  <li class="nav-item">
                    <a href="" class="nav-link">contact us</a>
                  </li>
                  <li class="nav-item">
                    <a href="" class="nav-link">customer servises</a>
                  </li>
                  <li class="nav-item">
                    <a href="" class="nav-link text-uppercarse">faq</a>
                  </li>
                  <li class="nav-item">
                    <a href="" class="nav-link">customer services</a>
                  </li>
                  <li class="nav-item">
                    <a href="" class="nav-link">contact us</a>
                  </li>
                </nav>
              </div>
  
              <div class="col-sm">
                 <nav class="footer-nav">
                      <li class="nav-item">
                           <a href="#" class="nav-link footer-heading">
                                newsletter
                           </a>
                         </li>
  
                         <li class="nav-item">
                          <a class="nav-link">
                           <div class="form-group">
                                <label for="">enter email</label>
                                <div class=""><input type="text" 
                                placeholder="xyz@design.com"
                                class="form-control" ></div>
                           </div>
                           <button class="btn btn-main btn-footer" >submit</button>
                          </a>
                         </li>
                      
                     </nav>
                </div>
              </div>
            </div>
          </div>
        </footer>

<footer>
    <div class="footer-secondary">
      <div class="row">
        <div class="col-sm-6">
          <div class="footer-text">
            all copy rights resived @lorem ipsum
          </div>
        </div>
        <div class="col-sm-6">
          <div class="social-icons">
            <div class="icon">
              <i class="fa-brands fa-facebook-f"></i>
            </div>
            <div class="icon">
              <i class="fa-brands fa-twitter"></i>
            </div>
            <div class="icon">
              <i class="fa-brands fa-instagram"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>