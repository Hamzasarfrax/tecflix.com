






<footer>
    <div class="footer-secondary">
      <div class="row">
        <div class="col-sm-6">
          <div class="footer-text">
            all copy rights resived @lorem ipsum
          </div>
        </div>
        <div class="col-sm-6">
          <div class="social-icons">
            <div class="icon">
              <i class="fa-brands fa-facebook-f"></i>
            </div>
            <div class="icon">
              <i class="fa-brands fa-twitter"></i>
            </div>
            <div class="icon">
              <i class="fa-brands fa-instagram"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>